Another an example README file. 
